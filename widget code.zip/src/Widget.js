import React, {Component} from 'react';
import {
    BrowserRouter as Router,
    Route
} from 'react-router-dom'

import AjoutePanier from './pages/ajoutePanier'
import ConnaissezMensuration from './pages/connaissezMensuration'
import Connexion from './pages/connexion'
import ConseilTaille from './pages/conseilTaille'
import ConseilTailleMensurations from './pages/conseilTailleMensurations'
import Erreur from './pages/erreur'
import Felicitations from './pages/felicitations'
import MesInfosPerso from './pages/mesInfosPerso'
import MesInfosPerso2 from './pages/mesInfosPerso2'
import RenseignerInfosBas from './pages/renseignerInfosBas'
import RenseignerMensurations from './pages/renseignerMensurations'
import RenseignezAutreMensurations from './pages/renseignezAutreMensurations'
import RenseignezMensurationsPourConnaitre from './pages/renseignezMensurationsPourConnaitre'
import SauvegardezInformations from './pages/sauvegardezInformations'

import './App.css';

class Widget extends Component {

    static pushToRoot() {
        for (var i = 0; i < history.length; i++) {
            history.back();
        }
    }

    render() {
        return (
            <div className="widget" style={{paddingRight: "40%", paddingBottom: "40%"}}>
                <Router>
                    <div style={{width:166.7+"%"}}>
                        <Route exact path="/" component={ConnaissezMensuration}/>
                        <Route path="/AjoutePanier" component={AjoutePanier}/>
                        <Route path="/Connexion" component={Connexion}/>
                        <Route path="/ConseilTaille" component={ConseilTaille}/>
                        <Route path="/ConseilTailleMensurations" component={ConseilTailleMensurations}/>
                        <Route path="/Erreur" component={Erreur}/>
                        <Route path="/Felicitations" component={Felicitations}/>
                        <Route path="/MesInfosPerso" component={MesInfosPerso}/>
                        <Route path="/MesInfosPerso2" component={MesInfosPerso2}/>
                        <Route path="/RenseignerInfosBas" component={RenseignerInfosBas}/>
                        <Route path="/RenseignerMensurations" component={RenseignerMensurations}/>
                        <Route path="/RenseignezAutreMensurations" component={RenseignezAutreMensurations}/>
                        <Route path="/RenseignezMensurationsPourConnaitre"
                               component={RenseignezMensurationsPourConnaitre}/>
                        <Route path="/SauvegardezInformations" component={SauvegardezInformations}/>
                    </div>
                </Router>
            </div>
        );
    }
}

export default Widget;
