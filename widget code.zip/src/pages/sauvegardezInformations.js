import React, {Component} from 'react';
import PropTypes from 'prop-types';
import {Row, Col, Grid} from 'react-bootstrap';

import ButtonNormal from "../components/Buttons/ButtonNormal";
import RadioButton from "../components/Input/RadioButton";
import InputText from "../components/Input/InputText"

class SauvegardezInformations extends Component {
    constructor(props) {
        super(props);
        this.onClick = this.onClick.bind(this);
        this.onChange = this.onChange.bind(this);
    }

    state = {
        prenom: "",
        adressEMail: "",
        mdp: ""
    }

    onClick() {
        const {history} = this.props;
        history.push("/RenseignezMensurationsPourConnaitre");
    }

    onChange(value, save) {
        switch (save) {
            case "prenom":
                this.setState({prenom: value});
                break;
            case "adressEMail":
                this.setState({adressEMail: value});
                break;
            case "mdp":
                this.setState({mdp: value});
                break;
            default:
                break;
        }
    }

    render() {
        return (
            <div>
                <center>
                    <Grid>

                        <div style={{marginTop: 5 + "%",width: 85 + "%"}}>

                            <p>Sauvegardez vos informations pour les retrouver directement lors de votre prochaine visite!</p>

                            <br/>
                            <br/>
                            <Row>
                                <Col xs={4} md={2}>
                                </Col>
                                <Col xs={2} md={2} style={{marginLeft: 10 + "%"}}>
                                    Vous êtes:
                                </Col>
                                <Col xs={2} md={2}>
                                    <RadioButton name="gender" text="Une Femme"/>
                                </Col>
                                <Col xs={2} md={2}>
                                    <RadioButton name="gender" text="Un Homme"/>
                                </Col>
                                <Col xs={2} md={1}>

                                </Col>
                                <Col xs={4} md={3}>

                                </Col>
                            </Row>
                            <br/>
                            <br/>
                            <Row>
                                <Col xs={3} md={2} >
                            </Col>
                                <Col xs={3} md={2} >
                                    <InputText type="text" text="Prénom" unit="" save="prenom"
                                               onChange={this.onChange}/>
                                </Col>
                                <Col xs={2} md={1} >
                                </Col>
                                <Col xs={4} md={3} >
                                    <InputText type="text" text="Adresse e-mail" unit="" save="adressEMail"
                                               onChange={this.onChange}
                                    />
                                </Col>
                                <Col xsHidden md={4} >
                                    <InputText type="password" text="Mot de passe" unit="" save="mdp"
                                               onChange={this.onChange}
                                    />
                                </Col>
                            </Row>
                            <br/>
                            <br/>
                            <br/>
                            <br/>
                            <center>
                            <ButtonNormal onClick={this.onClick} text="ENREGISTER MES INFORMATION"/>
                            </center>
                        </div>
                    </Grid>
                </center>
            </div>
        );
    }
}

SauvegardezInformations.propTypes = {
    history: PropTypes.object.isRequired
};

export default SauvegardezInformations;