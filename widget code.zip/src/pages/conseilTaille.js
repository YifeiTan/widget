import React, {Component} from 'react';
import dressInfo from '../imgs/dressInfo.jpg';
import sansMensuration from '../imgs/sansMensuration.jpg'
import ButtonNormal from "../components/Buttons/ButtonNormal";
import PropTypes from 'prop-types';
import {Row, Col, Grid} from 'react-bootstrap';

class ConseilTaille extends Component {
    constructor(props) {
        super(props);
        this.onClick = this.onClick.bind(this);
    }

    onClick() {
        const {history} = this.props;
        history.push("/AjoutePanier");
    }

    render() {
        return (
            <div>


                <Grid>
                    <Row>
                        <Col xs={6} md={4}>
                            <img src={dressInfo} style={{paddingTop: 13 + "%", marginLeft: "10%"}} alt="logo"/>
                        </Col>
                        <Col xs={12} md={8}>
                            <center>
                                <div style={{marginTop: 8 + "%", paddingLeft: 0 + "%", width: 69 + "%"}}>
                                    <Row>
                                        <img src={sansMensuration} alt="logo"/>
                                    </Row>
                                    <br/>
                                    <ButtonNormal onClick={this.onClick} text="AJOUTER AU PANIER"/>
                                </div>
                            </center>
                        </Col>
                    </Row>
                </Grid>

            </div>
        );
    }
}

ConseilTaille.propTypes = {
    history: PropTypes.object.isRequired
};

export default ConseilTaille;