import React, {Component} from 'react';
import PropTypes from 'prop-types';
import {Row, Col, Grid} from 'react-bootstrap';

import dressInfo from '../imgs/dressInfo.jpg';

import ButtonNormal from "../components/Buttons/ButtonNormal";
import ButtonReturn from "../components/Buttons/ButtonReturn";
import RadioButton from "../components/Input/RadioButton";
import InputText from "../components/Input/InputText"

class RenseignerInfosBas extends Component {
    constructor(props) {
        super(props);
        this.onClick = this.onClick.bind(this);
        this.onChange = this.onChange.bind(this);
        this.onClickGoBack = this.onClickGoBack.bind(this);
    }

    state = {
        age:"",
        poid:"",
        taille:"",
        soutienGorge:""
    };

    onClick() {
        const {history} = this.props;
        history.push("/ConseilTaille");
    }
    onClickGoBack() {
        const {history} = this.props;
        history.goBack();
    }

    onChange(value, save) {
        switch (save) {
            case "age":
                this.setState({age: value});
                break;
            case "poid":
                this.setState({poid: value});
                break;
            case "taille":
                this.setState({taille: value});
                break;
            case "soutienGorge":
                this.setState({soutienGorge: value});
                break;
            default:
                break;
        }
    }

    render() {
        return (
            <div>
                    <Grid>
                        <Row>
                            <Col xs={6} md={4}>
                                <img src={dressInfo} style={{paddingTop: 13 + "%",marginLeft:"10%"}} alt="logo"/>
                            </Col>
                            <Col xs={12} md={8}>
                                <div style={{marginTop: 8 + "%", paddingLeft: 10 + "%", width: 95 + "%"}}>
                                    <p>Merci de renseigner vos mensurations afin de connaître votre taille.</p>
                                    <br/>
                                    <Row>
                                        <Col xs={4} md={3}>
                                            Vous êtes:
                                        </Col>
                                        <Col xs={4} md={3}>
                                            <RadioButton name="gender" text="Une Femme"/>
                                        </Col>
                                        <Col xs={4} md={3}>
                                            <RadioButton name="gender" text="Un Homme"/>
                                        </Col>
                                        <Col xs={4} md={3}>
                                        </Col>
                                    </Row>
                                    <br/>
                                    <Row>
                                        <Col md={4}>
                                            <InputText type="text" text="Âge" unit="ans" save="age" onChange={this.onChange}/>
                                        </Col>
                                        <Col md={4}>
                                            <InputText type="text" text="Poid" unit="kg" save="poid" onChange={this.onChange}/>
                                        </Col>
                                        <Col md={4}>
                                            <InputText type="text" text="Taille" unit="cm" save="taille" onChange={this.onChange}/>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col md={4}>
                                            <InputText type="text" text="Soutien-gorge" unit="" save="soutienGorge"
                                                       onChange={this.onChange}/>
                                        </Col>
                                    </Row>
                                    <br/>
                                    <br/>
                                    <br/>
                                    <Row>
                                        <Col md={6}>
                                            <ButtonReturn onClick={this.onClickGoBack} text="Précédent"/>
                                        </Col>
                                        <Col md={6}>
                                            <ButtonNormal onClick={this.onClick} text="Connaître Ma Taille"/>
                                        </Col>
                                    </Row>
                                </div>
                            </Col>
                        </Row>
                    </Grid>

            </div>
        );
    }
}

RenseignerInfosBas.propTypes = {
    history: PropTypes.object.isRequired
};

export default RenseignerInfosBas;