import React, {Component} from 'react';
import PropTypes from 'prop-types';
import {Row, Col, Grid} from 'react-bootstrap';

import dressInfo from '../imgs/dressInfo.jpg';
import RadioButton from "../components/Input/RadioButton";
import ButtonReturn from"../components/Buttons/ButtonReturn";
import ButtonNormal from"../components/Buttons/ButtonNormal";
import InputText from "../components/Input/InputText";

class RenseignerMensurations extends Component {
    constructor(props) {
        super(props);
        this.onClick = this.onClick.bind(this);
        this.onClickGoBack = this.onClickGoBack.bind(this);
        this.onChange = this.onChange.bind(this);
    }

    state = {
        tourDePoitrine: 0,
        tourDeTaille: 0,
        tourDeHanches: 0
    };

    onChange(value,save) {
        switch (save){
            case "TourDePoitrine":
                this.setState({tourDePoitrine: value});
                break;
            case "TourDeTaille":
                this.setState({tourDeTaille: value});
                break;
            case "TourDeHanches":
                this.setState({tourDeHanches: value});
                break;
            default:
                break;
        }
    }

    onClick() {
        const {history} = this.props;
        history.push("/ConseilTailleMensurations");
    }

    onClickGoBack() {
        const {history} = this.props;
        history.goBack();
    }

    render() {
        return (
            <div>
                    <Grid>
                        <Row>
                            <Col xs={6} md={4}>
                                <img src={dressInfo} style={{paddingTop: 13 + "%",marginLeft:"10%"}} alt="logo"/>
                            </Col>
                            <Col xs={12} md={8}>
                                <div style={{marginTop: 8 + "%", paddingLeft: 10 + "%", width: 95 + "%"}}>
                                        <p>Merci de renseigner vos mensurations afin de connaître votre taille:</p>
                                    <br />
                                    <Row>
                                        <Col xs={4} md={3}>
                                            Vous êtes:
                                        </Col>
                                        <Col xs={4} md={3}>
                                            <RadioButton name="gender" text="Une Femme"/>
                                        </Col>
                                        <Col xs={4} md={3}>
                                            <RadioButton name="gender" text="Un Homme"/>
                                        </Col>
                                        <Col xs={4} md={3}>
                                        </Col>
                                    </Row>
                                    <br/>
                                    <Row>
                                        <Col md={4}>
                                            <InputText text="Tour de poitrine" unit="cm" save="TourDePoitrine"
                                                       onChange={this.onChange}/>
                                        </Col>
                                        <Col md={4}>
                                            <InputText text="Tour de taille" unit="cm" save="TourDeTaille"
                                                       onChange={this.onChange}
                                            />
                                        </Col>
                                        <Col md={4}>
                                            <InputText text="Tour de hanches" unit="cm" save="TourDeHanches"
                                                       onChange={this.onChange}
                                            />
                                        </Col>
                                    </Row>
                                    <br/>
                                    <br/>
                                    <br/>
                                    <Row>
                                        <Col md={6}>
                                            <ButtonReturn onClick={this.onClickGoBack} text="Précédent"/>
                                        </Col>
                                        <Col md={6}>
                                            <ButtonNormal onClick={this.onClick} text="Connaître Ma Taille"/>
                                        </Col>
                                    </Row>
                                </div>
                            </Col>
                        </Row>
                    </Grid>
                </div>
        );
    }
}

RenseignerMensurations.propTypes = {
    history: PropTypes.object.isRequired
};

export default RenseignerMensurations;