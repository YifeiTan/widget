import React, {Component} from 'react';
import felicitation from '../imgs/felicitation.jpg';
import ButtonNormal from "../components/Buttons/ButtonNormal";
import PropTypes from 'prop-types';

class Felicitations extends Component {
    constructor(props) {
        super(props);
        this.onClick = this.onClick.bind(this);
    }

    onClick() {
        const {history} = this.props;
        history.push("/");
    }

    render() {
        return (
            <div>
                <center>
                   <img src={felicitation}  alt="logo"/>
                    <ButtonNormal onClick={this.onClick} text="RETOURNEZ À L'ÉCRAN ACCUILLE"/>
                </center>
            </div>
        );
    }
}

Felicitations.propTypes = {
    history: PropTypes.object.isRequired
};

export default Felicitations;