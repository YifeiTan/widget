import React, {Component} from 'react';

class Link extends Component {
    render() {
        return (
            <div className="InfoInput">
                <a href="#">InfoInput</a>
            </div>
        )
    }
}


export default Link;