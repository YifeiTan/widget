import React, {Component} from 'react';
import PropTypes from 'prop-types';
import icon_femme from '../../imgs/icon_femme.jpg';
import icon_homme from '../../imgs/icon_homme.jpg';

class RadioButton extends Component {

    render() {
        if(this.props.text==="Une Femme"){
        return (
            <div className="RadioButton">
                <input type="radio" name={this.props.name}/><img src={icon_femme} alt="femme"/>{this.props.text}
            </div>
        )}
            return(
                <div className="RadioButton">
                    <input type="radio" name={this.props.name}/><img src={icon_homme} alt="homme"/>{this.props.text}
                </div>
            )
    }
}

RadioButton.propTypes = {
    text: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired
};

export default RadioButton;